const items=[
{Title:'Avatar',Box_Office:'$2,434,543,678',Active:'Yes',Date_Of_Launch:'15/03/2017',Genre:'Science fiction',Has_Teasre:'Yes'},
{Title:'The Avengers',Box_Office:'$1,436,543,018',Active:'Yes',Date_Of_Launch:'3/11/2017',Genre:'Superhero',Has_Teasre:'No'},
{Title:'Titanic',Box_Office:'$2,934723,818',Active:'Yes',Date_Of_Launch:'11/06/2017',Genre:'Romanse',Has_Teasre:'No'},
{Title:'Jurassic World',Box_Office:'$1,434,543,678',Active:'No',Date_Of_Launch:'1/12/2017',Genre:'Science fiction',Has_Teasre:'Yes'},
{Title:'Avengers : End Game',Box_Office:'$2,750,760,678',Active:'Yes',Date_Of_Launch:'22/03/2022',Genre:'Superhero',Has_Teasre:'Yes'}
];



const renderProducts=function(items)
{
let tabEl=document.querySelector("#itemsTable");

items.forEach(function(item){

let trEl1=document.createElement("tr");

let tdEl1=document.createElement("td");

tdEl1.setAttribute('class','tname');

tdEl1.textContent=item.Title;

trEl1.appendChild(tdEl1);

let tdEl2=document.createElement("td");

tdEl2.setAttribute('class','tprice');

tdEl2.textContent=item.Box_Office;

trEl1.appendChild(tdEl2);

let tdEl3=document.createElement("td");

tdEl3.setAttribute('class','tactive');

tdEl3.textContent=item.Active;

trEl1.appendChild(tdEl3);

let tdEl4=document.createElement("td");

tdEl4.setAttribute('class','tdol');

tdEl4.textContent=item.Date_Of_Launch;

trEl1.appendChild(tdEl4);

let tdEl5=document.createElement("td");

tdEl5.setAttribute('class','tcategory');

tdEl5.textContent=item.Genre;

trEl1.appendChild(tdEl5);

let tdEl6=document.createElement("td");

tdEl6.setAttribute('class','tfreedelivery');

tdEl6.textContent=item.Has_Teasre;

trEl1.appendChild(tdEl6);


tabEl.appendChild(trEl1);


let tdEl7=document.createElement("td");

tdEl7.setAttribute('class','taction');

                                let editLink=document.createElement('a');

                                editLink.setAttribute('id','link1');

                                editLink.textContent="Edit"
								
								editLink.href="edit-movie.html?"+"title="+items.Title+"&boxOffice="+items.Box_Office+"&active="+items.Active+"&dateofLaunch="+items.Date_Of_Launch+"&genre="+items.Genre+"&hasTeaser="+items.Has_Teasre;

                                tdEl7.appendChild(editLink);

                                trEl1.appendChild(tdEl7);



})
document.querySelector('#link1').addEventListener('click',function(){

console.log(item);

})


}




const customerProducts=function(items)
{
let tabEl=document.querySelector("#custTable");

items.forEach(function(item){

let trEl1=document.createElement("tr");

let tdEl1=document.createElement("td");

tdEl1.setAttribute('class','tname');

tdEl1.textContent=item.Title;

trEl1.appendChild(tdEl1);

let tdEl2=document.createElement("td");

tdEl2.setAttribute('class','tprice');

tdEl2.textContent=item.Box_Office;

trEl1.appendChild(tdEl2);

let tdEl5=document.createElement("td");

tdEl5.setAttribute('class','tcategory');

tdEl5.textContent=item.Genre;

trEl1.appendChild(tdEl5);

let tdEl6=document.createElement("td");

tdEl6.setAttribute('class','tfreedelivery');

tdEl6.textContent=item.Has_Teasre;

trEl1.appendChild(tdEl6);

tabEl.appendChild(trEl1);

let tdEl7=document.createElement("td");

tdEl7.setAttribute('class','taction');

                                let editLink=document.createElement('a');

                                editLink.setAttribute('id','link1');

                                editLink.href="movie-list-customer-notification.html";

                                editLink.textContent="Add To Favourite"

                                tdEl7.appendChild(editLink);

                                trEl1.appendChild(tdEl7);




})
document.querySelector('#link1').addEventListener('click',function(){

console.log(item);

})


}


const addfavProducts=function(items)
{
let tabEl=document.querySelector("#notTable");

items.forEach(function(item){

let trEl1=document.createElement("tr");

let tdEl1=document.createElement("td");

tdEl1.setAttribute('class','tname');

tdEl1.textContent=item.Title;

trEl1.appendChild(tdEl1);

let tdEl2=document.createElement("td");

tdEl2.setAttribute('class','tprice');

tdEl2.textContent=item.Box_Office;

trEl1.appendChild(tdEl2);

let tdEl5=document.createElement("td");

tdEl5.setAttribute('class','tcategory');

tdEl5.textContent=item.Genre;

trEl1.appendChild(tdEl5);

let tdEl6=document.createElement("td");

tdEl6.setAttribute('class','tfreedelivery');

tdEl6.textContent=item.Has_Teasre;

trEl1.appendChild(tdEl6);


tabEl.appendChild(trEl1);

let tdEl7=document.createElement("td");

tdEl7.setAttribute('class','taction');

                                let editLink=document.createElement('a');

                                editLink.setAttribute('id','link1');

                                editLink.href="movie-list-customer-notification.html";

                                editLink.textContent="Add To Favourite"

                                tdEl7.appendChild(editLink);

                                trEl1.appendChild(tdEl7);




})
document.querySelector('#link1').addEventListener('click',function(){

console.log(item);

})


}


const favouriteProducts=function(items)
{
let tabEl=document.querySelector("#favTable");

items.forEach(function(item){

let trEl1=document.createElement("tr");

let tdEl1=document.createElement("td");

tdEl1.setAttribute('class','tname');

tdEl1.textContent=item.Title;

trEl1.appendChild(tdEl1);

let tdEl2=document.createElement("td");

tdEl2.setAttribute('class','tprice');

tdEl2.textContent=item.Box_Office;

trEl1.appendChild(tdEl2);

let tdEl5=document.createElement("td");

tdEl5.setAttribute('class','tcategory');

tdEl5.textContent=item.Genre;

trEl1.appendChild(tdEl5);


tabEl.appendChild(trEl1);

let tdEl7=document.createElement("td");

tdEl7.setAttribute('class','taction');

                                let editLink=document.createElement('a');

                                editLink.setAttribute('id','link1');

                                editLink.href="favorites-notification.html";

                                editLink.textContent="Delete"

                                tdEl7.appendChild(editLink);

                                trEl1.appendChild(tdEl7);




})
document.querySelector('#link1').addEventListener('click',function(){

console.log(item);

})


}


let check = document.querySelector('#id').value;
if(check == 'admin')
	renderProducts(items);
else if(check == 'cust')
	customerProducts(items);
else if(check == 'fav')
	favouriteProducts(items);
else if(check == 'not')
	addfavProducts(items);

const validation=function(){
                console.log("Inside validation");
                var title=document.forms['MyForm']['title'].value;
                var boxoffice=document.forms['MyForm']['price'].value;
                var genre=document.forms['MyForm']['category'].value;
                var active=document.forms['MyForm']['active'].value;
                var dateOfLaunch=document.forms['MyForm']['dol'].value;
                if(title == "" || title == null){
                                alert("Title should not be empty.");
                                return false;
                }
                else if(boxoffice == "" || boxoffice == null){
                                alert("Box office should not be empty.");
                                return false;
                }
                else if(genre == "" || genre == null){
                                alert("Genre should not be empty.");
                                return false;
                }
                else if(active == "" || active == null){
                                alert("Please select whether the movie is in active or not.");
                                return false;
                }
                else if(dateOfLaunch == "" || dateOfLaunch == null){
                                alert("Please specify the date of launch of the movie.");
                                return false;
                }
                return true;
}



const editmovie=function(){
var getQueryString = function ( field, url ) {
    var href = url ? url : window.location.href;
    var reg = new RegExp( '[?&]' + field + '=([^&#]*)', 'i' );
    var string = reg.exec(href);
    return string ? string[1] : null;
};

var title = getQueryString("title");
document.querySelector("#title").value = title

var  boxOffice= getQueryString("boxOffice");
document.querySelector("#price").value = boxOffice

var dol = getQueryString("dateofLaunch");
document.querySelector("#dol").value = dol


var active = getQueryString("active");
if(active==="Yes")
document.querySelector("#active").checked = true

else
                document.querySelector("#No").checked = true

var hs = getQueryString("hasTeaser");
if(hs==="Yes")
document.querySelector("#hasTeaser").checked = true

else
                document.querySelector("#hasTeaser").checked = false

var cat = getQueryString("genre");
document.querySelector("#genre").value = cat
}




