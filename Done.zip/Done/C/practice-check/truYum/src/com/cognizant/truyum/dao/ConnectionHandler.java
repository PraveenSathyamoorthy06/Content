package com.cognizant.truyum.dao;

import com.mysql.jdbc.Connection;

public class ConnectionHandler {

	public Connection getConnection() {
		return null;
	}
	
}
