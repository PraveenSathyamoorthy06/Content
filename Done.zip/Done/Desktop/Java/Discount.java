package com.pack;
import java.util.*;
public class Discount{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		System.out.println("Price of item 1 : ");
		float item1=scan.nextFloat();
		System.out.println("Price of item 2 : ");
		float item2=scan.nextFloat();
		System.out.println("Discount in percentage : ");
		int discount=scan.nextInt();
		float totalCost=item1+item2;
		float discCost=totalCost/discount;
		float cost=totalCost-discCost;
		System.out.println("Total amount : $"+totalCost);
		System.out.println("Discount amount : $"+cost);
		System.out.println("Saved amount : $"+discCost);
	}
}