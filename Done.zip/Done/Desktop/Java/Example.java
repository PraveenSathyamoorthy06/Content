package com.pack;

import java.lang.annotation.*;
@Documented
@Target(ElementType.METHOD)

public @interface Example{

	String add();

}