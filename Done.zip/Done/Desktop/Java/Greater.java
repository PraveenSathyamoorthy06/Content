package com.pack;
import java.util.*;
public class Greater{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the first number");
		int x=scan.nextInt();
		System.out.println("Enter the second number");
		int y=scan.nextInt();
		if(x<y){
			System.out.println(x+" is less than "+y);
		}
		else if(y<x){
			System.out.println(x+" is greater than "+y);
		}
		else{
			System.out.println(x+" is equal to "+y);
		}
	}
}			