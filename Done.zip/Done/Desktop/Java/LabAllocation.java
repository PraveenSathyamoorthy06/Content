package com.pack;
import java.util.*;
public class LabAllocation{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter x");
		int x=scan.nextInt();
		System.out.println("Enter y");
		int y=scan.nextInt();
		System.out.println("Enter z");
		int z=scan.nextInt();
		if(x<y && x<z){
			System.out.println("L1 has the minimal seating capacity");
		}
		else if(y<z){
			System.out.println("L2 has the minimal seating capacity");
		}
		else{
			System.out.println("L3 has the minimal seating capacity");
		}
	}
}