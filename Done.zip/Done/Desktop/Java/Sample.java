package com.pack;	//package declaration
import java.util.*;	//import packages
class A{
	String s;	//instance variable
	A(String s1){	//parameterized constructor
 		s=s1;
	}
	public String toString(){
		return s;
	}
}
public class Sample{	//class declaration
	public static void main(String[] args){
		A a1=new A("hello");
		System.out.println(a1);		//hello -- if you invoke the constructor the object automatically calls toString method if available	
		String s2="hello";
		System.out.println(s2.charAt(2));
		String s1="this is a java code";
		int start=5;
		int end=10;
		char buff[]=new char[end-start];
		s1.getChars(start,end,buff,0);
		System.out.println(buff);
		byte b[]=s2.getBytes();
		for(byte b1:b){
			System.out.println(b1);
		}
		char c[]=s2.toCharArray();
		for(char c1:c){
			System.out.println(c1);
		}
		System.out.println("foobar".startsWith("foo"));
		System.out.println("foobar".startsWith("bar"));
		System.out.println(s2.length());
		String s3=new String("hello");
		System.out.println(s2.equals(s3));
		System.out.println(s2.equalsIgnoreCase(s3));
		System.out.println(s2==s3);
		String s4=s3;
		System.out.println(s3==s4);
		String s5="hello world";
		String s6="hello world";
		System.out.println(s5.equals(s6));
		System.out.println(s5==s6);
		System.out.println(s5.substring(2));
		System.out.println(s5.substring(2,7));
		System.out.println(s5.compareTo(s6));
		String s7="hello worle";
		System.out.println(s5.compareTo(s7));
		String s8="good";
		System.out.println(s5.compareTo(s8));
		String s9="the class is good and co-workers are the best companions";
		System.out.println(s9.indexOf('s'));
		System.out.println(s9.lastIndexOf('s'));
		System.out.println(s9.indexOf("the"));
		System.out.println(s9.lastIndexOf("the"));
		System.out.println(s9.indexOf("the",5));
		System.out.println(s9.lastIndexOf("the",40));
		System.out.println(s8.toUpperCase());
		String s11="BAD";
		System.out.println(s11.toLowerCase());
		String s10=" boys are back ";
		System.out.println(s10.length());
		System.out.println(s10.trim().length());
		System.out.println(s10.length());
		System.out.println(s2.concat("world"));
		System.out.println(s2.length());
		System.out.println(s2.replace('e','i'));
		System.out.println(s2);
		String s12="hello-world-is-excecuted";
		String[] s13=s12.split("-");
		for(String s14:s13){
			System.out.println(s14);
		}
		String s15="hello.world.is.excecuted";
		String[] s16=s15.split("//.");
		for(String s17:s16){
			System.out.println(s17);
		}
		String s18="hello*world*is*excecuted";
		String[] s19=s18.split("//*");
		for(String s20:s19){
			System.out.println(s20);
		}
		String s21="No pain, No gain. It is a proverb";
		String[] s22=s21.split("pain|gain|(It is a)");
		for(String s23:s22){
			System.out.println(s23);
		}
		System.out.println(String.format("|%5d|",4));
		System.out.println(String.format("|%-5d|",4));
		System.out.println(String.format("|%05d|",4));
		//System.out.println(String.format("|%-05d|",4));	//IllegalFormatFlagException
		System.out.println(String.format("|%5s|","hello world"));
		System.out.println(String.format("|%15s|","hello world"));
		System.out.println(String.format("|%-15s|","hello world"));
		System.out.println(String.format("|%5.2f|",123.4567));
		String s24="ABC Windows Test";
		System.out.println(s24.regionMatches(true,4,"windows",0,7));
	}
}