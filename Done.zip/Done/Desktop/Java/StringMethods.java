package com.pack;	//package declaration
import java.util.*;	//import packages
class A{
	String s;	//instance variable
	A(String s1){	//parameterized constructor
 		s=s1;
	}
	public String toString(){
		return s;
	}
}
public class StringMethods{	//class declaration
	public static void main(String[] args){
		A a1=new A("hello");
		System.out.println(a1);		//hello -- if you invoke the constructor the object automatically calls toString method if available	
		String s2="hello";
		System.out.println(s2.charAt(2));	//l -- character at index 2
		String s1="this is a java code";
		int start=5;
		int end=10;
		char buff[]=new char[end-start];
		s1.getChars(start,end,buff,0);		
		System.out.println(buff);	//is a  -- characters from index 5 to 10 stored in character array named buff
		byte b[]=s2.getBytes();
		for(byte b1:b){
			System.out.println(b1);		//104 101 108 108 111 -- characters in string s2 is converted into byte array(ascii values) in separate lines
		}
		char c[]=s2.toCharArray();
		for(char c1:c){
			System.out.println(c1);		//h e l l o -- characters in string s2 is converted into character array in separate lines
		}
		System.out.println("foobar".startsWith("foo"));		//true -- given string starts with "foo"
		System.out.println("foobar".startsWith("bar"));		//false -- given string dosen't starts with "bar"
		System.out.println("foobar".endsWith("foo"));		//false -- given string dosen't ends with "foo"
		System.out.println("foobar".endsWith("bar"));		//true -- given string ends with "bar"
		System.out.println(s2.length());		//5 -- length of string s2
		String s3=new String("hello");		
		System.out.println(s2.equals(s3));		//true -- s2 and s3 are same case sensitive
		System.out.println(s2.equalsIgnoreCase(s3));		//true -- s2  and s3 are same ignore case	
		System.out.println(s2==s3);		//false -- object reference of s2 and s3 are different
		String s4=s3;
		System.out.println(s3==s4);		//true -- same object reference for s2 and s3
		String s5="hello world";	
		String s6="hello world";
		System.out.println(s5.equals(s6));	//true -- s5and s6are same case sensitive	
		System.out.println(s5==s6);		//true -- s5 and s6 strings don't have object so it acts as normal equals method
		System.out.println(s5.substring(2));		//llo world -- substring of s5 from index 2 till end
		System.out.println(s5.substring(2,7));		//llo w -- substring of s5 from index 2 till index 7
		System.out.println(s5.compareTo(s6));		//0 -- s5 and s6 are equal
		String s7="hello worle";
		System.out.println(s5.compareTo(s7));		//-1 -- s5's ascii value is lesser than s7's ascii value
		String s8="good";
		System.out.println(s5.compareTo(s8));		//1 -- s5's ascii value is greater than s8's ascii value
		String s9="the class is good and co-workers are the best companions";
		System.out.println(s9.indexOf('s'));		//7 -- 's' occures first in index 7 of s9
		System.out.println(s9.lastIndexOf('s'));	//55 -- 's' occures last in index 55 of s9
		System.out.println(s9.indexOf("the"));		//0 -- "the" occurs first in index 0 of s9
		System.out.println(s9.lastIndexOf("the"));	//37 -- "the" occurs last in index 37 of s9
		System.out.println(s9.indexOf("the",5));	//37 -- "the" occurs first in index 37 of s9 after index 5 of s9
		System.out.println(s9.lastIndexOf("the",40));	//37 -- "the" occurs last in index 37 of s9 before index 40 of s9	
		System.out.println(s8.toUpperCase());		//GOOD -- lowercase in s8 is converted into uppercase
		String s11="BAD";
		System.out.println(s11.toLowerCase());		//bad -- uppercase in s11 is converted into lowercase
		String s10=" boys are back ";
		System.out.println(s10.length());		//15 -- length of s10
		System.out.println(s10.trim().length());	//13 -- after removing white spaces in string length of s10
		System.out.println(s10.length());		//15 -- length of s10 
		System.out.println(s2.concat("world"));		//helloworld -- s2 and "world" are joined
		System.out.println(s2.length());		//5 -- length of s2
		System.out.println(s2.replace('e','i'));	//hillo -- 'e' is replaced by 'i' in s2
		System.out.println(s2);				//hello -- s2
		String s12="hello-world-is-excecuted";
		String[] s13=s12.split("-");
		for(String s14:s13){
			System.out.println(s14);		//hello world is excecuted -- s12 is splited on basis of '-' and stored in a string array
		}
		String s15="hello.world.is.excecuted";
		String[] s16=s15.split("\\.");
		for(String s17:s16){
			System.out.println(s17);		//hello world is excecuted -- s15 is splited on basis of '.' and stored in a string array
		}
		String s18="hello*world*is*excecuted";
		String[] s19=s18.split("\\*");
		for(String s20:s19){
			System.out.println(s20);		//hello world is excecuted -- s18 is splited on basis of '*' and stored in a string array
		}
		String s21="No pain, No gain. It is a proverb";
		String[] s22=s21.split("pain|gain|(It is a)");
		for(String s23:s22){
			System.out.println(s23);		//No |, No |. | proverb -- s21 is splited where the given delimiter strings are present 
		}
		System.out.println(String.format("|%5d|",4));		//|    4| -- four spaces before(+) 4(total size 5) is printed
		System.out.println(String.format("|%-5d|",4));		//|4    | -- four spaces after(-) 4(total size 5) is printed
		System.out.println(String.format("|%05d|",4));		//|00004| -- four zeros before(+) 4(total size 5) is printed
		//System.out.println(String.format("|%-05d|",4));		// throws IllegalFormatFlagException
		System.out.println(String.format("|%5s|","hello world"));		//|hello world| -- since the size of string is larger than the specified value the complete string is printed
		System.out.println(String.format("|%15s|","hello world"));		//|    hello world| -- 4 spaces before(+) string(total size 15) is printed
		System.out.println(String.format("|%-15s|","hello world"));		//|hello world    | -- 4 spaces after(-) string(total size 15) is printed
		System.out.println(String.format("|%5.2f|",456123.4567));		//|456123.46| -- after . only 2 decimal values are taken
		String s24="ABC Windows Test";	
		System.out.println(s24.regionMatches(true,4,"windows",0,7));		//true -- string "windows" is present in s24 with given constraints 
	}
}