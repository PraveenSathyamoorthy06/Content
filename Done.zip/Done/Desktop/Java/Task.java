package com.pack;
class Task2{
	@Deprecated
	void add(){
		System.out.println("Hello World");
	}
}
public class Task{
	public static void main(String[] args){
		Task t=new Task();
		t.show();
}
@Example(add="hello")
public void show(){
System.out.println("show;");
}
}