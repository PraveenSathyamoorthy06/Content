package com.pack;	//package declaration
import java.util.*;	//import packages
class A{
	String s;	//instance variable
	A(String s1){	//parameterized constructor
 		s=s1;
	}
	public String toString(){
		return s;
	}
}
public class WrapperClass{	//class declaration
	public static void main(String[] args){
		String s="42";
		int i=Integer.parseInt(s);
		System.out.println(i);
		int j=Integer.parseInt(s,5);
		System.out.println(i);
		Integer i1=new Integer(33);
		System.out.println(i1.intValue());
		Integer i2=new Integer.valueOf(s);
		System.out.println(i2.intValue());
		float f1=3.14f,f2=3.14f;
		System.out.println(Float.compare(f1,f2));
		Float f3=new Float(3.14);
		Float f4=new Float(3.14);
		System.out.println(Float.compareTo(f3,f4));
		Float f5=new Float(Math.sqrt(-4));
		System.out.println(f5);
	}
}