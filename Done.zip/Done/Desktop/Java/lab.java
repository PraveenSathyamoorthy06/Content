package com.pack;
import java.util.*;
public class lab{
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter x");
		float x=scan.nextFloat();
		System.out.println("Enter y");
		float y=scan.nextFloat();
		System.out.println("Enter z");
		int z=scan.nextInt();
		if(x<y){
			if(x<z){
				System.out.println("L1 has the minimal seating capacity");
			}
		}
		else if(y<x){
			if(y<z){
				System.out.println("L2 has the minimal seating capacity");
			}
		}
		else if(z<x){
			if(z<y){
			System.out.println("L3 has the minimal seating capacity");
			}
		}
	}
}