package com.test;

class Box{			//base class
	double width;		//instance variables
	double height;
	double depth;
}	

public class Main {		//main class

	public static void main(String[] args) {	
		// TODO Auto-generated method stub
		Box b=new Box();		//object creation
		Box b1=new Box();		//one class can have many objects
		b.width=10;
		b.height=20;
		b.depth=15;
		b1.width=15;
		b1.height=10;
		b1.depth=25;
		double vol;			//local variable
		vol=b.width*b.height*b.depth;
		System.out.println(vol);
		vol=b1.width*b1.height*b1.depth;
		System.out.println(vol);

	}

}
