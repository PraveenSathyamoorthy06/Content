package com.test;

class Box1{			//base class
	double width;		//instance variables
	double height;
	double depth;
	public double volume(){
		return (width*height*depth);
	}
}	

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box1 b=new Box1();		//object creation
		b.width=10;
		b.height=20;
		b.depth=15;
		double vol=b.volume();
		System.out.print("Volume is "+vol);
	}

}
