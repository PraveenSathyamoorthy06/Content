package com.test;

class Box5{
	double width;
	double height;
	double depth;
	public double vol() {
		return width*height*depth;
	}
}

class BoxWeight extends Box5{
	double weight;
	public BoxWeight(double w,double h,double d,double we) {
		width=w;
		height=h;
		depth=d;
		weight = we;
	}
	
}

public class Main10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BoxWeight bw=new BoxWeight(10, 20, 15, 3);
		double vol;
		vol=bw.vol();
		System.out.println("Volume is "+vol);		//3000.0
		System.out.println("Weight is "+bw.weight);		//3.0
	}

}
