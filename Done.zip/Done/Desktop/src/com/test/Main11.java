package com.test;

class Box6{
	private double width;
	private double height;
	private double depth;
	public Box6(){
		width=-1;
		height=-1;
		depth=-1;
	}
	public Box6(Box6 ob){
		width=ob.width;
		height=ob.height;
		depth=ob.depth;
	}
	public Box6(double len){
		width=height=depth=len;
	}
	public Box6(double w,double h,double d){
		width=w;
		height=h;
		depth=d;
	}
	public double vol() {
		return width*height*depth;
	}
}

class BoxWeight1 extends Box6{
	double weight;
	public BoxWeight1() {
		super();
		weight = -1;
	}
	public BoxWeight1(BoxWeight1 ob) {
		super(ob);
		weight = ob.weight;
	}
	public BoxWeight1(double len,double we) {
		super(len);
		weight = we;
	}
	public BoxWeight1(double w,double h,double d,double we) {
		super(w,h,d);
		weight = we;
	}
}

class Shipment extends BoxWeight1{
	double cost;
	public Shipment(double w,double h,double d,double we,double c) {
		super(w,h,d,we);
		cost=c;
	}
	
}

public class Main11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*BoxWeight1 bw=new BoxWeight1();
		BoxWeight1 bw1=new BoxWeight1(2, 3, 4, 5);
		BoxWeight1 bw2=new BoxWeight1(5, 2);
		BoxWeight1 bw3=new BoxWeight1(bw1);
		double vol;
		vol=bw.vol(); 
		System.out.println("Volume is "+vol+"  "+"Weight is "+bw.weight); 		//Volume is -1.0  Weight is -1.0
		vol=bw1.vol();
		System.out.println("Volume is "+vol+"  "+"Weight is "+bw1.weight);		//Volume is 24.0  Weight is 5.0
		vol=bw2.vol();
		System.out.println("Volume is "+vol+"  "+"Weight is "+bw2.weight);		//Volume is 125.0  Weight is 2.0
		vol=bw3.vol();
		System.out.println("Volume is "+vol+"  "+"Weight is "+bw3.weight);		//Volume is 24.0  Weight is 5.0
*/		
		Shipment s=new Shipment(1, 2, 3, 4, 5);
		double vol=s.vol();
		System.out.println("Volume is "+vol+"  Weight is "+s.weight+"  Cost is "+s.cost);		//Volume is 6.0  Weight is 4.0  Cost is 5.0
		}

}
