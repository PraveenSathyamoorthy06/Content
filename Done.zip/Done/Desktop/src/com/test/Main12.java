package com.test;

class Task{
	int i;
}

class SubTask extends Task{
	int i;
	public SubTask(int a,int b) {
		super.i=a;
		i=b;
	}
	public void show() {
		System.out.println(super.i+" "+i);
	}
}

public class Main12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubTask st=new SubTask(10, 20);
		st.show();
	}

}
