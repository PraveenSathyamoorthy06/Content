package com.test;

class Task1{
	public Task1() {
		System.out.println("Task1");
	}
	public Task1(int a) {
		System.out.println("Task1 int");
	}
}

class SubTask1 extends Task1{		
	public SubTask1() {
		System.out.println("SubTask1");
	}
}

class InnerTask1 extends SubTask1{		
	public InnerTask1() {
		System.out.println("InnerTask1");
	}
}

public class Main13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new InnerTask1();		//Task1 SubTask1 InnerTask1
	}

}
