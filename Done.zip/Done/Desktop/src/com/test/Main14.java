package com.test;

class Task2{
	{
		System.out.println("1");		//compound block/instance block gets executed before constructor invokes 
	}
	static {
		System.out.println("2");
	}
	{
		System.out.println("3");
	}
	public Task2() {
		System.out.println("4");
	}
	static {
		System.out.println("5");
	}
	public Task2(String s) {
		this();
		System.out.println("6");
	}
}

class SubTask2 extends Task2{
	static {
		System.out.println("7");
	}
	{
		System.out.println("8");
	}
	static {
		System.out.println("8a");
	}
	public SubTask2() {
		this(10);
		System.out.println("9");
	}
	public SubTask2(int a) {
		super("hello");
		System.out.println("10");
		System.out.println("11");
	}
}

class InnerTask2 extends SubTask2{
	{
		System.out.println("12");
	}
	static {
		System.out.println("13");
	}
	public InnerTask2() {
			System.out.println("14");
	}
	{
		System.out.println("15");
	}
	public InnerTask2(String s) {
		this();
		System.out.println("16");
	}
	static {
		System.out.println("17");
	}
}

public class Main14 {
	static {
		System.out.println("18");
	}
	public static void main(String[] args) {
		System.out.println("19");
		new InnerTask2("hel");
		System.out.println("20");
	}
	static {
		System.out.println("21");
	}
}
//18 21 19 2 5 7 8a 13 17 1 3 4 6 8 10 11 9 12 15 14 16 20