package com.test;

class Task3{
	public void show(){
		System.out.println("base class method");
	}
}

class SubTask3 extends Task3{
	public void show(){
		super.show();
		System.out.println("derived class method");
	}
}

public class Main15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubTask3 sb=new SubTask3();
		sb.show();
	}

}
