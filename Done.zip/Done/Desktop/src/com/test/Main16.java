package com.test;

class Task4{
	public void call(){
		System.out.println("Task4 base class method");
	}
}

class SubTask4 extends Task4{
	public void call(){
		System.out.println("SubTask4 derived class method");
	}
}

class InnerTask4 extends Task4{
	public void call(){
		System.out.println("InnerTask4 derived class method");
	}
}

public class Main16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Task4 t=new Task4();		//Task4 base class method
		t.call();
		t=new SubTask4();			//SubTask4 derived class method
		t.call();
		t=new InnerTask4();			//InnerTask4 derived class method
		t.call();
	}

}
