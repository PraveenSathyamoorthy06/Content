package com.test;

class Employee{
	private int age;
	private String name;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [age=" + age + ", name=" + name + "]";
	}
		
}

public class Main17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.setAge(220);
		emp.setName("RajaRajaCholan");
		System.out.println(emp.getAge());		//220
		System.out.println(emp.getName().hashCode());		//
		System.out.println(emp);			//Employee [age=220, name=RajaRajaCholan]
		String s2="hello";
		String s1=new String("hello");
		System.out.println(s2.hashCode()+" "+s1.hashCode());		//99162322 99162322
	}

}
