package com.test;

abstract class Task5{
	abstract void show();
	public void show1() {
		System.out.println("normal method is displayed");
	}
}

class SubTask5 extends Task5{
	@Override
	void show() {
		System.out.println("abstract method is displayed");
	}
}

public class Main18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubTask5 sb=new SubTask5();
		sb.show();		//abstract method is displayed
		sb.show1();		//normal method is displayed
	}

}
