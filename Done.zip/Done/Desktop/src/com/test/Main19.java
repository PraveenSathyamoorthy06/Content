package com.test;

class Task6 implements Max{
	@Override
	public void arithmetic(int a, int b) {
		System.out.println(a+b+Max.c);
	}
}

class SubTask6 implements Max{
	@Override
	public void arithmetic(int a, int b) {
		System.out.println(a-b-Max.c);
	}
	public void show() {
		System.out.println("Non-implemented method");
	}
}

public class Main19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Max m=new Task6();
		m.arithmetic(10, 20);		//50
		m=new SubTask6();
		m.arithmetic(50, 10);		//20
		//m.show();					//Compilation error : The method show() is undefined for the type Max
		( (SubTask6) m).show();		//Non-implemented method : since show method is not present in interface
	}

}
