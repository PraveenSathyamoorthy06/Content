package com.test;

class Box2{			//base class
	double width;		//instance variables
	double height;
	double depth;
	public void setDim(double w,double h,double d) {
		width=w;
		height=h;
		depth=d;
	}
	public double volume(){
		return (width*height*depth);
	}
}	

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box2 b=new Box2();		//object creation
		b.setDim(10, 20, 30);
		double vol=b.volume();
		System.out.print("Volume is "+vol);
	}

}
