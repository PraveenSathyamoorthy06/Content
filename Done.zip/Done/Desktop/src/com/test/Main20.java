package com.test;

interface Task7{
	void add1();
}

interface SubTask7{
	void add2();
}

interface InnerTask7 extends SubTask7,Task7{
	void add3();
}

class BaseTask implements InnerTask7{
	@Override
	public void add2() {
		System.out.println("add of SubTask");
	}
	@Override
	public void add1() {
		System.out.println("add of Task");
	}
	@Override
	public void add3() {
		System.out.println("add of InnerTask");
	}
}

public class Main20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BaseTask bt=new BaseTask();
		bt.add1();		//add of Task
		bt.add2();		//add of SubTask
		bt.add3();		//add of InnerTask
	}

}
