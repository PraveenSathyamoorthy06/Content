package com.test;

class Task8{
	final int a=10;
	public void display() {
		System.out.println("display method of Task8 displays a final variable a value "+a);
	}
}

final class SubTask8 extends Task8{		//if class Task8 is final -- Compilation error: The type SubTask1 cannot subclass the final class Task1
	public void display() {				//if display() in Task8 is final -- Compilation error: class com.test.SubTask8 overrides final method display.()
		System.out.println("display method of SubTask8");
	}
}

class InnerTask8 extends Task8{		//if class Task8 is final -- Compilation error: The type SubTask1 cannot subclass the final class Task1
	final public void display1() {			
		System.out.println("display method of InnerTask8");
	}
}

public class Main21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Task8 t=new Task8();		
		t.display();					//display method of Task8 displays a final variable  a value 10
		//t.a=11;						//Compilation error: The final field Task8.a cannot be assigned
		t=new SubTask8();			
		t.display();					//display method of SubTask8
		t=new InnerTask8();			
		((InnerTask8) t).display1();	//display method of InnerTask8
	}

}
