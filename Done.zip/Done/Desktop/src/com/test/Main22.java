package com.test;

public class Main22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			int d,a=10;
			d=a/0;
			System.out.println(d);			//if try catch not used -- Exception in thread "main" java.lang.ArithmeticException: / by zero
		}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println(e);		//java.lang.ArithmeticException: / by zero
		}
	}

}
