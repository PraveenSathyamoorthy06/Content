package com.test;

public class Main23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			 int b=42/0;
			int[] a= {1};
			a[20]=50;
		}
		/*catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println(e);			//java.lang.ArithmeticException: / by zero

		}
		catch (ArrayIndexOutOfBoundsException e1) {
			// TODO: handle exception
			System.out.println(e1);			//java.lang.ArrayIndexOutOfBoundsException: 20
		}*/
		catch (ArithmeticException |ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
