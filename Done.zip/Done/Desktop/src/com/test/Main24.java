package com.test;

public class Main24 {
	static void demo() {
		//System.out.println("demo");
		try {
			throw new NullPointerException();
		}
		catch(NullPointerException exception) {
			System.out.println("caught "+exception);		//caught java.lang.NullPointerException
			throw exception;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			demo();
		}
		catch(NullPointerException exception) {
			System.out.println("re-caught "+exception);		//re-caught java.lang.NullPointerException
		}
	}

}
