package com.test;


public class Main25 {
	static void demo() {
		//System.out.println("demo");
		try {
			System.out.println("Inside demo");
			throw new RuntimeException();
		}
		finally {
			System.out.println("demo finally");
		}
	}
	static void demo1() {
		//System.out.println("demo");
		try {
			System.out.println("Inside demo1");
			return;
		}
		finally {
			System.out.println("demo1 finally");
		}
	}
	static void demo2() {
		//System.out.println("demo");
		try {
			System.out.println("Inside demo2");
		}
		finally {
			System.out.println("demo2 finally");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			demo();									//Inside demo
		}											//demo finally
		catch(Exception exception) {				//Caught
			System.out.println("Caught");			//Inside demo1			
		}											//demo1 finally	
		demo1();									//Inside demo2			
		demo2();									//demo2 finally				
	}

}
