package com.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Main27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> al=new ArrayList<Employee>();		//generics(used to mention the type of list) from jdk1.5 
		List<Employee> al1=new ArrayList<>();		//from jdk1.7
		List<String> l=new ArrayList<>();
		System.out.println(l.size());			//0
		l.add("a");
		l.add("g");
		l.add("d");
		l.add("r");
		l.add("y");
		System.out.println(l.size());				//5
		
		Iterator li1=l.iterator();
		while(li1.hasNext()) {
			Object o=li1.next();
			System.out.println(o);				//a+ g+ d+ r+ y+
		}
		ListIterator li=l.listIterator();
		while(li.hasNext()) {
			Object o=li.next();
			li.set(o+"+ ");
		}
		li=l.listIterator();
		while(li.hasNext()) {
			Object o=li.next();
			System.out.println(o);				//a+ g+ d+ r+ y+
		}
		System.out.println("\n");
		while(li.hasPrevious()) {
			Object o=li.previous();
			System.out.println(o);
		}
		System.out.println(l);
		l.remove(2);
		l.remove("y");
		System.out.println(l);
		ArrayList<String> al2=new ArrayList<>();
		al2.addAll(l);
		System.out.println("al2"+al2);
		System.out.println(al2.contains("g"));
		System.out.println(al2.containsAll(l));
		al2.removeAll(l);
		System.out.println(al2);
	}

}
