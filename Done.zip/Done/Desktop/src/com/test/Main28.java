package com.test;

import java.util.LinkedList;
import java.util.List;

public class Main28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> l=new LinkedList<>();
		System.out.println(l.size());		//0
		l.add(10);
		l.add(2);
		l.addFirst(13);
		l.addLast(5);
		l.add(17);
		l.add(2, 9);
		System.out.println(l);		//[13, 10, 9, 2, 5, 17]
		l.remove(2);
		l.removeFirst();
		l.removeLast();
		System.out.println(l);			//[10, 2, 5]
		System.out.println(l.get(1));		//2
		System.out.println(l.getFirst());		//10
		System.out.println(l.getLast());		//5
	}

}
