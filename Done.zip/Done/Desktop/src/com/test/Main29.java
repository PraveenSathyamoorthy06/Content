package com.test;

import java.util.Enumeration;
import java.util.Vector;

public class Main29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v=new Vector<>(3, 2);
		System.out.println(v.size()+" "+v.capacity());			//0 3
		v.add(1);
		v.add(2);
		v.add(3);
		v.add(4);
		System.out.println(v.size()+" "+v.capacity());			//4 5
		v.add(5);
		v.add(6);
		System.out.println(v.size()+" "+v.capacity());			//6 7
		v.add(7);
		v.add(8);
		System.out.println(v.size()+" "+v.capacity());			//8 9
		System.out.println(v);
		Enumeration e=v.elements();		//Enumeration interface(legacy)
		while(e.hasMoreElements()) {
			System.out.println(e.nextElement());
		}
	}

}
