package com.test;

class Box3{			//base class
	double width;		//instance variables
	double height;
	double depth;
	
	public Box3() {
		width=10;
		height=20;
		depth=15;
	}

	public double volume(){
		return (width*height*depth);
	}
}	

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box3 b=new Box3();		//object creation
		double vol=b.volume();
		System.out.print("Volume is "+vol);
	}

}
