package com.test;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Main30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Map<String,Double> hm=new HashMap<>();
		//Map<String,Double> hm=new LinkedHashMap<>();
		//Map<String,Double> hm=new TreeMap<>();
		Hashtable<String,Double> hm=new Hashtable();
		System.out.println(hm.size());			//0
		hm.put("arul", 253.64);
		hm.put("surendhar kaka", 9.2034);
		hm.put("praveen dd", -987.1);
		hm.put("arul", 53.6);
		hm.put("rishad", 61.8);
		System.out.println(hm);				//{arul=53.6, surendhar kaka=9.2034, rishad=61.8, praveen dd=-987.1} -- in a random order
		Set s=hm.entrySet();
		Iterator it=s.iterator();
		while(it.hasNext()) {
			Map.Entry me=(Entry) it.next();
			System.out.println(me.getKey()+" "+me.getValue()+" -- entrySet");		//HashMap/LinkedHashMap : arul 53.6 surendhar kaka 9.2034 rishad 61.8 praveen dd-987.1
		}
		s=hm.keySet();
		it=s.iterator();
		while(it.hasNext()) {
			String s1=(String) it.next();
			System.out.println(s1+" "+hm.get(s1)+" -- keySet");		//TreeSet : arul 53.6 praveen dd-987.1 rishad 61.8 surendhar kaka 9.2034 
		}
		Enumeration e=hm.keys();
		while(e.hasMoreElements()) {
			String s1=(String) e.nextElement();
			System.out.println(s1+" "+hm.get(s1)+" -- Enumeration");		//HashMap : rishad 61.8 arul 53.6 praveen dd-987.1 surendhar kaka 9.2034
		}
	}

}
