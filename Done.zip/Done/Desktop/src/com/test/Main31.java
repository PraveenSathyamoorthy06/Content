package com.test;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class Main31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties p=new Properties();
		System.out.println(p.size());
		p.put("Tom Riddle", "villan");
		p.put("Harry Potter", "Hero");
		p.put("Albus De Dumbuldore", "Well-Wisher");
		p.put("Ron willson", "friend");
		p.put("Sirius Black", "paternal uncle");
		System.out.println(p);				//{Ron willson=friend, Albus De Dumbuldore=Well-Wisher, Harry Potter=Hero, Tom Riddle=villan, Sirius Black=paternal uncle}
		Set s=p.keySet();
		Iterator it=s.iterator();
		while(it.hasNext()) {
			String s1=(String) it.next();
		System.out.println(s1+" "+p.getProperty(s1)+" -- Properties class");  //Ron willson friend Albus De Dumbuldore Well-Wisher Harry Potter Hero Tom Riddle villan Sirius Black paternal uncle 
		}
	}

}
