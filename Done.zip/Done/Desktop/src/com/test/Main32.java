package com.test;

import java.util.Date;

public class Main32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d1=new Date();
		System.out.println(d1);				//Tue Jul 23 10:39:22 IST 2019
		Date d2=new Date(10000000);			
		System.out.println(d2);				//Thu Jan 01 08:16:40 IST 1970
		System.out.println(d1.compareTo(d2));		//1
		System.out.println(d1.after(d2));			//true
		System.out.println(d1.before(d2));			//false
		System.out.println(d2.getTime());			//10000000
	}

}
