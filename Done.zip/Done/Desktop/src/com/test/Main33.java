package com.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Main33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar calendar=Calendar.getInstance();
		System.out.println(calendar.getTime());			//Tue Jul 23 11:44:25 IST 2019
		Date d1=new Date(2000000000);
		Calendar calendar2=Calendar.getInstance();		
		System.out.println(calendar2.getTime());		//Tue Jul 23 11:44:25 IST 2019
		System.out.println(calendar.get(calendar.YEAR));		//2019
		System.out.println(calendar.get(calendar.MONTH));		//6
		System.out.println(calendar.get(calendar.DATE));		//23
		calendar.add(calendar.YEAR, -4);						
		System.out.println(calendar.get(calendar.YEAR));		//2015
		calendar.set(calendar.MONTH, 9);		
		System.out.println(calendar.MONTH);						//9
		System.out.println(calendar.getMaximum(calendar.YEAR));			//292278994
		System.out.println(calendar.getMinimum(calendar.YEAR));			//1
		System.out.println(calendar2.getActualMaximum(calendar.MONTH));			//11
		System.out.println(calendar2.getActualMinimum(calendar.MONTH));			//0
		System.out.println(calendar.get(calendar.DAY_OF_YEAR));					//296
		GregorianCalendar gCalendar=new GregorianCalendar();
		System.out.println(gCalendar);							//java.util.GregorianCalendar[time=1563862510973,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id="Asia/Calcutta",offset=19800000,dstSavings=0,useDaylight=false,transitions=6,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=2019,MONTH=6,WEEK_OF_YEAR=30,WEEK_OF_MONTH=4,DAY_OF_MONTH=23,DAY_OF_YEAR=204,DAY_OF_WEEK=3,DAY_OF_WEEK_IN_MONTH=4,AM_PM=0,HOUR=11,HOUR_OF_DAY=11,MINUTE=45,SECOND=10,MILLISECOND=973,ZONE_OFFSET=19800000,DST_OFFSET=0]
		int year=gCalendar.get(calendar2.YEAR);
		System.out.println(gCalendar.isLeapYear(year));			//false
		Date d2=calendar2.getTime();
		System.out.println(calendar+" -- "+d2);       //java.util.GregorianCalendar[time=1445581189022,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id="Asia/Calcutta",offset=19800000,dstSavings=0,useDaylight=false,transitions=6,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=2015,MONTH=9,WEEK_OF_YEAR=43,WEEK_OF_MONTH=4,DAY_OF_MONTH=23,DAY_OF_YEAR=296,DAY_OF_WEEK=6,DAY_OF_WEEK_IN_MONTH=4,AM_PM=0,HOUR=11,HOUR_OF_DAY=11,MINUTE=49,SECOND=49,MILLISECOND=22,ZONE_OFFSET=19800000,DST_OFFSET=0] -- Tue Jul 23 11:49:49 IST 2019
	}

}
