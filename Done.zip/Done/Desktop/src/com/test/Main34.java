package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d=new Date();
		System.out.println(d);				//Tue Jul 23 12:05:55 IST 2019
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter date of birth(dd/MM/yy)");		//Enter date of birth(dd/MM/yy)
		String date=sc.nextLine();									//29/06/98
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yy");
		sd.setLenient(false);			
		
		try {
			d=sd.parse(date);
			System.out.println(d);			//Mon Jun 29 00:00:00 IST 1998
		}
		catch(ParseException p) {
			System.out.println(p);
		}
		sd=new SimpleDateFormat("dd-MM-yyyy");
		String s1=sd.format(d);
		System.out.println(s1);					//29-06-1998
	}

}
