package com.test;

import java.io.File;

public class Main35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("C:\\New folder\\test.txt");
		System.out.println(f.getName());			//test.txt
		System.out.println(f.getPath());			//C:\New folder\test.txt
		System.out.println(f.getAbsolutePath());	//C:\New folder\test.txt
		System.out.println(f.getParent());			//C:\New folder
		System.out.println(f.isFile());				//true
		System.out.println(f.isDirectory());		//false
		System.out.println(f.length());				//7
		System.out.println(f.lastModified());		//1563864893296
		System.out.println(f.canRead());			//true
		System.out.println(f.canWrite());			//true
		System.out.println(f.isHidden());			//false
	}

}
