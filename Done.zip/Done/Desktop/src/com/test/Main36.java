package com.test;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main36 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter fw = new FileWriter("C:\\New folder\\testWrite.txt");
		fw.write("muttonkushkawa");
		fw.close();
		FileReader fr=new FileReader("C:\\New folder\\testWrite.txt");
		int i;
		while((i=fr.read()) != -1)
			System.out.println((char)i);			//m u t t o n k u s h k a w a
		fr.close();
	}

}
