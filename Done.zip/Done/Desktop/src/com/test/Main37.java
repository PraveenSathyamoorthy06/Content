package com.test;

public class Main37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb=new StringBuffer("hello");
        System.out.println(sb.length());		//5
        System.out.println(sb.charAt(1));		//e
        sb.setCharAt(1, 'i');				
        System.out.println(sb);				//hillo
        sb.setLength(2);
        System.out.println(sb);				//hi
        System.out.println(sb.capacity());		//21
        String s;
        int a=42;
        StringBuffer sb1=new StringBuffer();		
        s=sb1.append("a= ").append(a).append("!").toString();		
        System.out.println(s);										//a= 42!
        StringBuffer sb2=new StringBuffer("I Java!");
        sb2.insert(2,"like ");
        System.out.println(sb2);									//I like Java!
        StringBuffer sb4=new StringBuffer("ancdef");
        sb4.reverse();
        System.out.println(sb4);									//fedcna
        StringBuffer sb5=new StringBuffer("This is a test.");
        sb5.deleteCharAt(1);
        System.out.println(sb5);									//Tis is a test.
        StringBuffer sb6=new StringBuffer("This is a test.");
        sb6.replace(5, 7, "was");
        System.out.println(sb6);									//This was a test.
	}

}
