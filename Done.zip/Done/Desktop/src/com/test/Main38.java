package com.test;

class NewThread2 extends Thread{
	public NewThread2() {
		super("Demo Thread");
		System.out.println(this);					//Thread[threadname(main by default),thread priority(5 by default),ThreadGroupName(main by default)]
		start();								//Thread[Demo Thread,5,main]	
	}																					
	@Override
	public void run() {
		try {
			for(int i=5;i>0;i--) {
				System.out.println("Child Thread "+i);
				Thread.sleep(500);
			}
		}
		catch(InterruptedException exception){
			System.out.println("Child Thread Existing");
		}
	}
}

class NewThread implements Runnable{
	Thread t;
	public NewThread() {
		t=new Thread(this, "Demo Thread");
		System.out.println(t);					//Thread[threadname(main by default),thread priority(5 by default),ThreadGroupName(main by default)]
		t.start();								//Thread[Demo Thread,5,main]	
	}																					
	@Override
	public void run() {
		try {
			for(int i=5;i>0;i--) {
				System.out.println("Child Thread "+i);
				Thread.sleep(500);
			}
		}
		catch(InterruptedException exception){
			System.out.println("Child Thread Existing");
		}
	}
}

public class Main38 {
	public static void main(String[] args) {
		new NewThread();
		new NewThread2();
		try {
			for(int i=5;i>0;i--) {
				System.out.println("Main Thread "+i);
				Thread.sleep(2000);
				
			}
		}
		catch(InterruptedException exception){
			System.out.println("Main Thread Existing");
		}
	}

}
