package com.test;

class NewThread1 extends Thread{
	public NewThread1() {
		super("Demo Thread");
		System.out.println(this);					//Thread[threadname(main by default),thread priority(5 by default),ThreadGroupName(main by default)]
		start();								//Thread[Demo Thread,5,main]	
	}																					
	@Override
	public void run() {
		try {
			for(int i=5;i>0;i--) {
				System.out.println("Child Thread "+i);
				Thread.sleep(500);
			}
		}
		catch(InterruptedException exception){
			System.out.println("Child Thread Existing");
		}
	}
}

public class Main39 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new NewThread1();
		try {
			for(int i=5;i>0;i--) {
				System.out.println("Main Thread "+i);
				Thread.sleep(2000);
				
			}
		}
		catch(InterruptedException exception){
			System.out.println("Main Thread Existing");
		}
	}

}
