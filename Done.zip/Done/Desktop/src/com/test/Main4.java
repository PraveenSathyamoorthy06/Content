package com.test;

class A{
	
	void test(){
		System.out.println("no parameter");
	}
	void test(int a){
		System.out.println("no parameter"+a);
	}
	void test(int a,int b){
		System.out.println("no parameter"+a+b);
	}
	double test(double a){
		System.out.println("no parameter"+a);
		return a*a;
	}
}

public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a=new A();
		a.test();
		a.test(10);
		a.test(10, 20);
		double res= a.test(3.15);
		System.out.println(res);
	}

}
