package com.test;

class Callme {
    void call(String msg) {
           System.out.print("[" + msg);
           try {
                  Thread.sleep(1000);
           } catch (InterruptedException e) {
                  System.out.println("Interrupted");
           }
           System.out.println("]");
    }
}

class Caller implements Runnable {
    String msg;
    Callme target;
    Thread t;

    Caller(Callme targ, String s) {
           target = targ;
           msg = s;
           t = new Thread(this);
           t.start();
    }

    @Override
    public void run() {
         synchronized (target) {
        	 target.call(msg);
		}  
    }

}

public class Main40 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Callme target=new Callme();
		Caller o1=new Caller(target,"Hello");
		Caller o2=new Caller(target,"Synchronized");
		Caller o3=new Caller(target,"World");
		try {
			o1.t.join();					//[World[Synchronized[Hello]
			o2.t.join();					//]
			o3.t.join();					//]	
		}
		catch (InterruptedException e) {		//synchronized keyword used for call method / synchronized block is used : [Hello] [Synchronized] [World]
			System.out.println("Interupted");
		}
	}

}
