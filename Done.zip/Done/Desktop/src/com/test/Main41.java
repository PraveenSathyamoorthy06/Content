package com.test;

public class Main41 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main41 m=new Main41();
		m.show();
	}
	@Example(add="hello")
	public void show(){
		System.out.println("show()");
		}

}
