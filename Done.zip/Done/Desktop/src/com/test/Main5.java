package com.test;

class Varargs{
	void test(int...a) {
		for(int a1:a)
			System.out.println(a1);
	}
	void test(boolean...b) {
		for(boolean b1:b)
			System.out.println(b1);
	}
	void test(int a,String...s) {
		System.out.println(a);
		for(String s1:s)
			System.out.println(s1);
	}
}

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Varargs v=new Varargs();
		v.test(10,20,30,50);
		v.test(true,false,true,true);
		v.test(100, "var", "args", "is", "used");
	}

}
