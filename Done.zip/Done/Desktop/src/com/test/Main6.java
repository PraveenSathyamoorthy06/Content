package com.test;

class Sample{
	int a=10;
	public Sample() {
		this(10);
	}
	public Sample(int a) {
		this("Method");
		System.out.println(a+this.a);
	}
	public Sample(String s) {
		System.out.println(s);
	}
}

public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Sample();
	}

}
