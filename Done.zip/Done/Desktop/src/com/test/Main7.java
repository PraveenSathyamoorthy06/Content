package com.test;

class Test{
	static int x=5;
	public static void display() {
		System.out.println("static dispaly method in different class");
	}
}

public class Main7 {
	static int a=10;
	static int c;
	int b=20;
	static {		//initialized before execution of main method since static block
		System.out.println("static block initialized");
		c=a*10;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t=new Test();
		t.display(); 		//warning : change 'static' modifier to 'display()'
		Test.display();		//static disp1ay method in different class
		display();			//static display method in same class
		//display1();		//compilation error : Cannot make a static reference to the non-static method display1() from the type Main7
		System.out.println(a+" "+c);			//10 100
		//System.out.println(b);		//compilation error : Cannot make a static reference to the non-static field b
		Main7 m7=new Main7();
		System.out.println(m7.b);		//20
		System.out.println(Test.x);		//5
	}
	public void display1() {
		System.out.println("static display1 method in same class");
	}
	public static void display() {
		System.out.println("static display method in same class");
	}
}
