package com.test;

import static java.lang.Math.*;
import static java.lang.System.*;

public class Main8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double d=sqrt(16);
		out.println(d);
	}

}
