package com.test;

public class Main9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent p=new Parent();
		p.i=5;
		p.j=6;
		p.show();
		Child c=new Child();
		c.i=9;
		c.j=10;
		c.k=11;
		c.showk();
		c.sum();
	}

}
