package com.test;

public interface Max {
	public void arithmetic(int a,int b);
	int c=20;
}