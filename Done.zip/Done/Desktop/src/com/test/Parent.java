package com.test;

public class Parent {		//base/parent/super class
	int i,j;
	void show() {
		System.out.println(i+" "+j);
	}
}

class Child extends Parent{		//derived/child class
	int k;
	void showk() {
		System.out.println(k);
	}
	void sum() {
		System.out.println(i+j+k);
	}
}