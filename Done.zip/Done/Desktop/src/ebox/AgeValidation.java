package ebox;

import java.util.Scanner;

class InvalidAgeException extends Exception{

	@Override
	public String toString() {
		return "Exception occured: InvalidAgeException: not valid";
	}
	
}

public class AgeValidation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		try {
			System.out.println("Enter your age ");
			int age=sc.nextInt();
			if(age<18)
					throw new InvalidAgeException();
			System.out.println("welcome to vote ");
		}
		catch(InvalidAgeException ig) {
			System.out.println(ig);
		}
	}

}
