package ebox;

import java.util.Scanner;

class Shape{
	protected String shapeName; 
	
	public Shape(String shapeName) {
		super();
		this.shapeName = shapeName;
	}

	public Double calculateArea() {
		return 0.00;
	}
}

class Square extends Shape{
	Integer side;
	
	public Square(String shapeName, Integer side) {
		super(shapeName);
		this.side = side;
	}

	public Double calculateArea() {
		return (double) (side*side);
	}
}

class Rectangle extends Shape{
	Integer length;
	Integer breath;
	
	public Rectangle(String shapeName, Integer length, Integer breath) {
		super(shapeName);
		this.length = length;
		this.breath = breath;
	}
	
	public Double calculateArea() {
		return (double) (length*breath);
	}
}

class Circle extends Shape{
	Integer radius;

	public Circle(String shapeName, Integer radius) {
		super(shapeName);
		this.radius = radius;
	}
	
	public Double calculateArea() {
		return (double) (3.14*radius*radius);
	}
	
}

public class AreaOfShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Rectangle \n2. Square \n3. Circle \nArea Calculator --- Choose your shape ");
		int choice=sc.nextInt();
		switch(choice) {
			case 1:{
				System.out.println("Enter length and breadth: ");
				int l=sc.nextInt();
				int b=sc.nextInt();
				Rectangle r=new Rectangle("Rectangle", l, b);
				System.out.println("Area of Rectangle is:"+r.calculateArea());
				break;
			}
			case 2:{
				System.out.println("Enter side: ");
				int side=sc.nextInt();
				Square s=new Square("Square", side);
				System.out.println("Area of Square is:"+s.calculateArea());
				break;
			}
			case 3:{
				System.out.println("Enter radius: ");
				int r=sc.nextInt();
				Circle c=new Circle("Circle", r);
				System.out.println("Area of Circle is:"+c.calculateArea());
				break;
			}
		}
	}

}
