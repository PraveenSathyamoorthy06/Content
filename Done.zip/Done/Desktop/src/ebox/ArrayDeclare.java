package ebox;

import java.util.Scanner;

public class ArrayDeclare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str= {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the day number");
		int day=scan.nextInt();
		System.out.println("Day of week is "+str[day-1]);
	}

}
