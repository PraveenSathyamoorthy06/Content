package ebox;

import java.util.Scanner;

public class ArrayWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		int size=scan.nextInt();
		int[] arr=new int[size];
		int sum=0, i=0;
		while(i<size) {
			arr[i]=scan.nextInt();
			sum+=arr[i];
			i++;
		}
		System.out.println(sum);
	}

}
