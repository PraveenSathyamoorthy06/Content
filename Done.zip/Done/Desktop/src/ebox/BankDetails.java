package ebox;

import java.util.Scanner;

class Account{
	private String accountNumber;
	private int balance;
	public Account(String accountNumber, int balance) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBalance() {
		return balance;
	}
	public void deposit(int transactionAmount) {
		balance+=transactionAmount;
	}
	public void withdraw(int transactionAmount) {
		if(transactionAmount<=balance)
			balance-=transactionAmount;
		else
			System.out.println("Insufficient Balance ");
	}
}

public class BankDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Account Number ");
		String accountNumber=sc.next();
		System.out.println("Enter the Account Balance ");
		int balance=sc.nextInt();
		Account ac=new Account(accountNumber, balance);
		System.out.println("Enter 1 to deposit an amount, 2 to withdraw an amount ");
		int option=sc.nextInt();
		int amount;
		if(option==1) {
			System.out.println("Enter the amount to deposit");
			amount=sc.nextInt();
			ac.deposit(amount);
		}
		else if(option==2) {
			System.out.println("Enter the amount to withdraw ");
			amount=sc.nextInt();
			ac.withdraw(amount);
		}
		System.out.println("Your balance after the transaction is: "+ac.getBalance());
	}

}
