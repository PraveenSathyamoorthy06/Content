package ebox;

import java.util.Scanner;

abstract class Card{
	protected String holderName; 
	protected String cardNumber; 
	protected String expiryDate;
	public Card(String holderName, String cardNumber, String expiryDate) {
		super();
		this.holderName = holderName;
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
}

class PaybackCard extends Card{
	Integer pointsEarned; 
	Double totalAmount;
	
	public PaybackCard(String holderName, String cardNumber, String expiryDate, Integer pointsEarned,
			Double totalAmount) {
		super(holderName, cardNumber, expiryDate);
		this.pointsEarned = pointsEarned;
		this.totalAmount = totalAmount;
	}
	public Integer getPointsEarned() {
		return pointsEarned;
	}
	public void setPointsEarned(Integer pointsEarned) {
		this.pointsEarned = pointsEarned;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	} 
}

class MembershipCard extends Card{
	Integer rating;

	public MembershipCard(String holderName, String cardNumber, String expiryDate, int rating) {
		super(holderName, cardNumber, expiryDate);
		this.rating = rating;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}
	
}


public class CardDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Select the Card  \n1.Payback Card  \n2.Membership Card  ");
		int choice=Integer.parseInt(sc.nextLine());
		System.out.println("Enter the Card Details: ");
		String details=sc.nextLine();
		String[] cDetails=details.split("\\|");
		switch(choice) {
			case 1:{
				System.out.println("Enter points in card ");
				int points=sc.nextInt();
				System.out.println("Enter Amount  ");
				double amount=sc.nextInt();
				PaybackCard p=new PaybackCard(cDetails[0], cDetails[1], cDetails[2], points, amount);
				System.out.println(p.holderName+" Payback Card Details: \nCard Number "+p.cardNumber+"\nPoints Earned "+p.pointsEarned+"\nTotal Amount "+p.totalAmount);
				break;
			}
			case 2:{
				System.out.println("Enter points in card ");
				int rating=sc.nextInt();
				MembershipCard m=new MembershipCard(cDetails[0], cDetails[1], cDetails[2], rating);
				System.out.println(m.holderName+" Membership Card Details: \nCard Number "+m.cardNumber+"\nRating "+m.rating);
				break;
			}
		}
	}

}
