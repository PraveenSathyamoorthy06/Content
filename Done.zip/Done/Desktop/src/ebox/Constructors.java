package ebox;

import java.util.Scanner;

class Product1{
	private int id;
	private String productName;
	private String supplierName;
	
	public Product1() {
		
	}
	
	public Product1(int i,String p,String s) {
		id=i;
		productName=p;
		supplierName=s;
	}
	
	public void display() {
		System.out.println("Product Id is "+id);
		System.out.println("Product Name is "+productName);
		System.out.println("Supplier Name is "+supplierName);
	}
}

public class Constructors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the product id ");
		int id=scan.nextInt();
		System.out.println("Enter the product name ");
		String pName=scan.next();
		System.out.println("Enter the supplier name ");
		String sName=scan.next();
		Product1 gs=new Product1(id,pName,sName);
		gs.display();
	}

}
