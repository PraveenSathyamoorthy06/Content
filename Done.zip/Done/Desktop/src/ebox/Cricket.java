package ebox;

import java.util.Scanner;

class Delivery{
	void displayDeliveryDetails(String bowler, String batsman) {
		String bowlerName[]=bowler.split(" ");
		String batsmanName[]=batsman.split(" ");
		System.out.println("Player details of the delivery: \nBowler : "+bowlerName[bowlerName.length-1]+"\nBatsman : "+batsmanName[batsmanName.length-1]);
	}
	void displayDeliveryDetails(Long runs) {
		System.out.println("Number of runs scored in the delivery : " +runs);
		if(runs==4)
			System.out.println("It is a boundary.");
		else if(runs==6)
			System.out.println("It is a Sixer.");
	}
}

public class Cricket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Delivery d=new Delivery();
		System.out.println("Menu \n1.Player details of the delivery \n2.Run details of the delivery ");
		int choice=Integer.parseInt(sc.nextLine());
		switch(choice) {
			case 1:{
				System.out.println("Enter the bowler name ");
				String bowler=sc.nextLine();
				System.out.println("Enter the batsman name ");
				String batsman=sc.nextLine();
				d.displayDeliveryDetails(bowler, batsman);
				break;
			}
			case 2:{
				System.out.println("Enter the number of runs ");
				Long runs=sc.nextLong();
				d.displayDeliveryDetails(runs);
				break;
			}
		}
	}

}
