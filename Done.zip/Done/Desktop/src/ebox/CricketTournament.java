package ebox;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class CricketTournament {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		long run;
		String name;
		Map<String,Long> map=new HashMap<>();
		System.out.println("Enter the number of players ");
		int option=Integer.parseInt(sc.nextLine());
		for(int i=0;i<option;i++) {
			System.out.println("Enter the details of the player "+(i+1));
			name=sc.nextLine();
			run=Long.parseLong(sc.nextLine());
			map.put(name, run);
		}
		Long maxRun = Collections.max(map.values());
		for(Entry<String, Long> entry:map.entrySet()) {
			if(entry.getValue()==maxRun)
				System.out.println(entry.getKey());
		}
	}

}
