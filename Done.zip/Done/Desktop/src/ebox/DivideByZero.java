package ebox;

import java.util.Scanner;

class DivideByZeroException extends ArithmeticException{

	@Override
	public String toString() {
		return "DivideByZeroException caught";
	}
	
}

public class DivideByZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		try{
			System.out.println("Enter the 2 numbers");
			int d=sc.nextInt(),a=sc.nextInt();
			if(a==0)
				throw new DivideByZeroException();
			int sum=d/a;
			System.out.println("The quotient of "+d+"/"+a+"="+sum);			//if try catch not used -- Exception in thread "main" java.lang.ArithmeticException: / by zero
		}
		catch (DivideByZeroException e) {
			// TODO: handle exception
			System.out.println(e);		//java.lang.ArithmeticException: / by zero
		}
		finally {
			System.out.println("Inside finally block");
		}
	}

}