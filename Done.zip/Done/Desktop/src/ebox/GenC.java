package ebox;

import java.util.Scanner;

class Student{
	private int employeeId;
	private String name;
	private static final String COHORT_CODE = "CHNAJ19004";

	public Student() {
		super();
	} 
	
	public Student(int employeeId, String name) {
		super();
		this.employeeId = employeeId;
		this.name = name;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void display() {
		System.out.println(employeeId+" "+name+" "+COHORT_CODE);
	}
	
}

public class GenC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of GenCs ");
		int count=scan.nextInt();
		Student s[]=new Student[count];
		for(int i=0;i<count;i++) {
			System.out.println("Enter the Employee id ");
			int id=scan.nextInt();
			System.out.println("Enter name ");
			String pName=scan.next();
			s[i]=new Student();
			s[i].setEmployeeId(id);
			s[i].setName(pName);
		}
		for(int i=0;i<count;i++) {
			s[i].display();
		}
	}

}
