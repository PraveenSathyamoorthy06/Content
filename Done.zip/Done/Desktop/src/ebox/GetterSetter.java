package ebox;

import java.util.Scanner;

class Product{
	private int id;
	private String productName;
	private String supplierName;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
}

public class GetterSetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		Product gs=new Product();
		System.out.println("Enter the product id ");
		int id=scan.nextInt();
		System.out.println("Enter the product name ");
		String pName=scan.next();
		System.out.println("Enter the supplier name ");
		String sName=scan.next();
		gs.setId(id);
		gs.setProductName(pName);
		gs.setSupplierName(sName);
		System.out.println("Product Id is "+gs.getId());
		System.out.println("Product Name is "+gs.getProductName());
		System.out.println("Supplier Name is "+gs.getSupplierName());
	}

}
