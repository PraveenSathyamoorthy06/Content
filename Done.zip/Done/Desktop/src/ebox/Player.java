package ebox;

import java.util.Scanner;

interface IPlayerStatistics{
	public void displayPlayerStatistics();
}

abstract class Players{
	protected String name;
	protected String teamName;
	protected int noOfMatches;
	public Players(String name, String teamName, int noOfMatches) {
		super();
		this.name = name;
		this.teamName = teamName;
		this.noOfMatches = noOfMatches;
	}
}

class CricketPlayer extends Players implements IPlayerStatistics{
	private int totalRunsScored;
	private int noOfWicketsTaken;
	public CricketPlayer(String name, String teamName, int noOfMatches, int totalRunsScored, int noOfWicketsTaken) {
		super(name, teamName, noOfMatches);
		this.totalRunsScored = totalRunsScored;
		this.noOfWicketsTaken = noOfWicketsTaken;
	}
	@Override
	public void displayPlayerStatistics() {
		// TODO Auto-generated method stub
		System.out.println("Player Details \nPlayer name:" + name + "\nTeam name:" + teamName
				+ "\nNo of matches:" + noOfMatches + "\nTotal runsscored:" + totalRunsScored + "No of wickets taken:" + noOfWicketsTaken);
	}
}

class HockeyPlayer extends Players implements IPlayerStatistics{
	private String position;
	private int noOfGoals;
	public HockeyPlayer(String name, String teamName, int noOfMatches, String position, int noOfGoals) {
		super(name, teamName, noOfMatches);
		this.position = position;
		this.noOfGoals = noOfGoals;
	}
	@Override
	public void displayPlayerStatistics() {
		// TODO Auto-generated method stub
		System.out.println("Player Details \nPlayer name:" + name + "\nTeam name:" + teamName
				+ "\nNo of matches:" + noOfMatches + "\nPosition:"
				+ position + "\n No of goals taken:" + noOfGoals);
	}
}

public class Player {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		IPlayerStatistics ip;
		System.out.println("Menu\n1.Cricket Player Details\n2.Hockey Player Details\nEnter choice ");
		int option=Integer.parseInt(sc.nextLine());
		switch(option) {
		case 1:
		{
			System.out.println("Enter player name ");
			String name=sc.nextLine();
			System.out.println("Enter team name ");
			String tName=sc.nextLine();
			System.out.println("Enter number of matches played ");
			int matches=sc.nextInt();
			System.out.println("Enter total runs scored ");
			int runs=sc.nextInt();
			System.out.println("Enter total number of wickets taken");
			int wickets=sc.nextInt();
			ip=new CricketPlayer(name, tName, matches, runs, wickets);
			ip.displayPlayerStatistics();
			break;
		}
		case 2:
		{
			System.out.println("Enter player name ");
			String name=sc.nextLine();
			System.out.println("Enter team name ");
			String tName=sc.nextLine();
			System.out.println("Enter number of matches played ");
			int matches=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the position");
			String position=sc.nextLine();
			System.out.println("Enter total number of goals taken");
			int goals=sc.nextInt();
			ip=new HockeyPlayer(name, tName, matches, position, goals);
			ip.displayPlayerStatistics();
			break;
		}
		}
		
	}

}
