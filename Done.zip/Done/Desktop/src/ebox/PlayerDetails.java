package ebox;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

class Player1{
	private String name;
	private String country;
	private String skill;
	public Player1(String name, String country, String skill) {
		super();
		this.name = name;
		this.country = country;
		this.skill = skill;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return String.format("%-15s",name) + "" + String.format("%-15s",country) + "" + String.format("%-15s",skill);
	} 
}

class PlayerBO{
	void displayAllPlayerDetails(ArrayList playerList) {
		Iterator it = playerList.iterator();
		System.out.println("Player Details");
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}

public class PlayerDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of players");
		int count=Integer.parseInt(sc.nextLine());
		Player1 p;
		ArrayList<String> list=new ArrayList<>();
		String name,country,skill;
		for(int i=0;i<count;i++) {
			System.out.println("Enter the player name  ");
			name=sc.nextLine();
			System.out.println("Enter the country name  ");
			country=sc.nextLine();
			System.out.println("Enter the skill  ");
			skill=sc.nextLine();
			p=new Player1(name, country, skill);
			list.add(p.toString());
		}
		new PlayerBO().displayAllPlayerDetails(list);
	}

}
