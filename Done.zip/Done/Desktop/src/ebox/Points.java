package ebox;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Points {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		List<Integer> list=new ArrayList<>();
		int count=sc.nextInt(),j,sum=0;
		for(int i=0;i<count;i++) {
			j=sc.nextInt();
			list.add(j);
			sum+=j;
		}
		System.out.println(sum);
		System.out.printf("%.2f",(float)sum/count);
	}

}
