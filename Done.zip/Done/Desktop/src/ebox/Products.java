package ebox;

import java.util.Scanner;

class Product5{
	private Long id;
	private String productName;
	private String supplierName;
	public Product5(Long id, String productName, String supplierName) {
		super();
		this.id = id;
		this.productName = productName;
		this.supplierName = supplierName;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + ((supplierName == null) ? 0 : supplierName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product5 other = (Product5) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (supplierName == null) {
			if (other.supplierName != null)
				return false;
		} else if (!supplierName.equals(other.supplierName))
			return false;
		return true;
	}
}

public class Products {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the product id ");
		long id=sc.nextLong();
		System.out.println("Enter the product name ");
		String productName=sc.next();
		System.out.println("Enter the supplier name ");
		String supplierName=sc.next();
		Product5 p=new Product5(id, productName, supplierName);
		System.out.println("Product Id is "+p.getId()+"\nProduct Name is "+p.getProductName()+"\nSupplier Name is "+p.getSupplierName());
		System.out.println("Enter the product id ");
		id=sc.nextLong();
		System.out.println("Enter the product name ");
		productName=sc.next();
		System.out.println("Enter the supplier name ");
		supplierName=sc.next();
		Product5 p1=new Product5(id, productName, supplierName);
		System.out.println("Product Id is "+p.getId()+"\nProduct Name is "+p.getProductName()+"\nSupplier Name is "+p.getSupplierName());
		if(p.equals(p1))
			System.out.println("The two products are the same");
		else
			System.out.println("The two products are different");
		System.out.println(p.getId()+":"+p.getProductName()+":"+p.getSupplierName());
		System.out.println("Invoking getClass() method :"+p.getClass());
	}

}
