package ebox;

import java.util.Scanner;

public class RepalceString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the content of the document");
		String content=scan.nextLine();
		System.out.println("Enter the old name of the company");
		String old=scan.nextLine();
		System.out.println("Enter the new name of the company");
		String ne=scan.next();
		String modified=content.replaceAll(old, ne);
		System.out.println("The content of the modified document is\n"+modified);
	}

}
