package ebox;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

class Box{
	double height;
	double width;
	double depth;
	public Box(double height, double width, double depth) {
		super();
		this.height = height;
		this.width = width;
		this.depth = depth;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getDepth() {
		return depth;
	}
	public void setDepth(double depth) {
		this.depth = depth;
	}
	@Override
	public String toString() {
		return "height=" + height + ", width=" + width + ", depth=" + depth +" Volume="+(height*width*depth);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(depth);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(height);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(width);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Box other = (Box) obj;
		if (Double.doubleToLongBits(depth) != Double.doubleToLongBits(other.depth))
			return false;
		if (Double.doubleToLongBits(height) != Double.doubleToLongBits(other.height))
			return false;
		if (Double.doubleToLongBits(width) != Double.doubleToLongBits(other.width))
			return false;
		return true;
	}	
}

public class SetOfBoxes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Box> s=new HashSet<>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Box ");
		int option=sc.nextInt();
		double len,wid,dep;
		for(int i=0;i<option;i++) {
			System.out.println("Enter the Box "+(i+1)+" details");
			System.out.println("Enter Length ");
			len=sc.nextDouble();
			System.out.println("Enter Width  ");
			wid=sc.nextDouble();
			System.out.println("Enter Height ");
			dep=sc.nextDouble();
			Box box=new Box(len, wid, dep);
			if(s.isEmpty())
				s.add(box);
			else {
				boolean flag=false;
				for(Box temp:s) {
					if(temp.equals(box)) {
						flag=true;
						break;
					}
				}
				if(flag==false)
					s.add(box);
					
			}
		}
		for(Box tempBox:s)
			System.out.println(tempBox);
	}

}
