package ebox;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class SortPoints {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		List<Integer> list=new ArrayList<>();
		int count=sc.nextInt(),j;
		for(int i=0;i<count;i++) {
			j=sc.nextInt();
			list.add(j);
		}
		Collections.sort(list);
		Iterator it=list.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
