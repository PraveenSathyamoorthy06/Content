package ebox;

import java.util.Scanner;

public class StartsWith {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=scan.nextLine();
		System.out.println("Enter the start string");
		String start=scan.next();
		if(str.startsWith(start))
			System.out.println("\""+str+" starts with \""+start+"\"");
		else
			System.out.println("\""+str+" does not starts with \""+start+"\"");
	}

}
