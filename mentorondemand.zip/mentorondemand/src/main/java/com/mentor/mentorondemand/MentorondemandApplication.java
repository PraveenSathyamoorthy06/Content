package com.mentor.mentorondemand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MentorondemandApplication {

	public static void main(String[] args) {
		SpringApplication.run(MentorondemandApplication.class, args);
	}

}
